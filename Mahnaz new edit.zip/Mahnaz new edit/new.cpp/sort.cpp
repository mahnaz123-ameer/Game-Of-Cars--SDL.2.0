void highscore(int t)
{
FILE *fp;
fp = fopen("highscore.txt","r");
int i, j,temp,ar[20];
for(i=0;i<10;i++){
	fscanf(fp,"%d",&ar[i]);
}
//fclose(fp);
if(t>ar[9]){
	ar[9] = t;
	for(i=0;i<10;i++){
		for(j=i;j<10;j++){
			temp=ar[i];
			ar[i]=ar[j];
			ar[j]=temp;
		}
	}
	fp = fopen("highscore.txt","r");

	for(i=0;i<10;i++){
		fprintf(fp,"%d\n",ar[i]);

	}
	fclose(fp);